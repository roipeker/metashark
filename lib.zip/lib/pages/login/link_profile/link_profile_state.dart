part of 'link_profile.dart';

abstract class _LinkProfileState extends State<LinkProfilePage> {
  
  String get titleText => 'Link Profile page';

  @override
  void initState(){
    super.initState();  
  }

  @override
  void dispose(){
    super.dispose();  
  }
}

