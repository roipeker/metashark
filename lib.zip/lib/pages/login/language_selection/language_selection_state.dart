part of 'language_selection.dart';

abstract class _LanguageSelectionState extends State<LanguageSelectionPage> {
  
  String get titleText => 'Language Selection page';

  @override
  void initState(){
    super.initState();  
  }

  @override
  void dispose(){
    super.dispose();  
  }
}

