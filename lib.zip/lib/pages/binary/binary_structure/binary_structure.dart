import 'package:metashark/commons.dart';
part 'binary_structure_state.dart';

class BinaryStructurePage extends StatefulWidget {
   // static const url = "/binary-structure";
  static const urlParamId = "structure";

  const BinaryStructurePage({Key? key}) : super(key: key);
  
  @override
  createState() => _BinaryStructurePage();
}

class _BinaryStructurePage extends _BinaryStructureState {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(titleText),
      ),
      body: const Center(
        child: Text('Content for Binary Structure page'),
      ),
    );
  }
}

