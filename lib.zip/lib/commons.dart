export 'dart:async';
export 'dart:math';

// export 'package:easy_localization/easy_localization.dart' hide TextDirection;
export 'package:flutter/material.dart';
export 'package:flutter_svg/flutter_svg.dart';
export 'package:gap/gap.dart';
export 'package:my_commons/my_commons.dart' hide NavigatorExt;
export 'package:animations/animations.dart';
// export 'package:faker/faker.dart';
export 'package:recase/recase.dart';
export 'package:modal_bottom_sheet/modal_bottom_sheet.dart';
export 'data/data.dart';
export 'package:flutter/foundation.dart';
export 'package:go_router/go_router.dart';

// export 'i18n/i18n.dart';
export 'pages/pages.dart';
export 'res/resources.dart';
export 'services/services.dart';
export 'utils/utils.dart';
export 'widgets/widgets.dart';
export 'mock/mock.dart';
export 'pages/routes.dart';
