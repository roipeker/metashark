part of 'invalid_form.dart';

abstract class _InvalidFormState extends State<InvalidFormPage> {
  
  String get titleText => 'Invalid Form page';

  @override
  void initState(){
    super.initState();  
  }

  @override
  void dispose(){
    super.dispose();  
  }
}

