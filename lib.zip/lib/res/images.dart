part of 'resources.dart';

class Images {
  Images._();
}
