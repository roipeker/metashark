import 'dart:async';
import 'dart:html' as html;
import 'dart:js' as js;
import 'package:metashark/commons.dart';

void trace2(String msg) {
  js.context.callMethod('trace', [msg]);
}

abstract class WebUtils {
  static late html.BodyElement body;
  static late html.Element div;

  static void init() {
    if (!kIsWeb) {
      return;
    }
    div =
        html.document.getElementsByTagName('flt-glass-pane')[0] as html.Element;
    body = html.document.getElementsByTagName('body')[0] as html.BodyElement;
    div.addEventListener('touchstart', _onTouch, true);

    /// inject viewport!
    var viewportContent =
        'width=device-width,initial-scale=1,maximum-scale=1,user-scalable=0,viewport-fit=cover';
    // var ref =
    //     'width=device-width, initial-scale=1.0, maximum-scale=3.0, user-scalable=yes, viewport-fit=cover';

    Timer(1000.milliseconds, () {
      var views = html.document.getElementsByName("viewport");
      if (views.isNotEmpty) {
        var e = views.first;
        if (e is html.Element) {
          e.setAttribute('content', viewportContent);
        }
      }
    });
  }

  static void _onTouch(html.Event event) {
    if (event is html.TouchEvent) {
      var a = event.touches!.first;
      var touch = a.screen;
      if (touch.x < 30) {
        trace("Cancel back history.");
        event.preventDefault();
      }
    }
  }

  static EdgeInsets getSafeArea() {
    var jsArray = js.context.callMethod('getSafeArea') as js.JsArray;
    var stringValues = jsArray.cast<String>();
    trace2('getSafeArea() $stringValues');

    // js.context.
    // top/right/bottom/left
    var doubleValues = stringValues.map2((e) {
      /// clean!
      var valString = e.replaceAll('px', '').replaceAll('%', '').trim();
      var valDouble = double.tryParse(valString);
      trace2("VALS: ${valString}|${valDouble}");
      return valDouble ?? 0.0;
    });
    return EdgeInsets.fromLTRB(
      doubleValues[3],
      doubleValues[0],
      doubleValues[1],
      doubleValues[2],
    );
  }

  static void computeSafeArea() {
    if (!kIsWeb) {
      return;
    }
    var res = js.context.callMethod('computeValue');
    trace('computeSafeArea() $res');
  }
}
