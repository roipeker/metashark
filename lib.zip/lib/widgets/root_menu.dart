import 'package:metashark/commons.dart';

final kRootMenuKey = GlobalKey<ScaffoldState>();

/// todo: clean the code.
late List<String> rootMenuUrls = kRootMenuList.map2((e) {
  if (e.url.isNotEmpty) {
    var url = router.namedLocation(e.url);
    return url;
  }
  return '';
});

bool locationHasDrawer(String loc) {
  var hasIt = rootMenuUrls.contains(loc);
  return hasIt;
}

class RootMenu extends StatefulWidget {
  final Widget child;
  final bool hasDrawerEnabled;

  const RootMenu({
    Key? key,
    this.hasDrawerEnabled = false,
    required this.child,
  }) : super(key: key);

  @override
  State<RootMenu> createState() => RootMenuState();

  static RootMenuState? of(BuildContext context) {
    return context.findAncestorStateOfType<RootMenuState>();
  }
}

class RootMenuState extends State<RootMenu> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: kRootMenuKey,
      drawerEnableOpenDragGesture: widget.hasDrawerEnabled,
      drawer: const RootMenuDrawer(),
      onDrawerChanged: (e) {
        trace("DRAWER changed to : $e");
      },
      body: widget.child,
    );
  }

  void open() {
    final _state = kRootMenuKey.currentState;
    if (_state != null) {
      if (!_state.isDrawerOpen) {
        _state.openDrawer();
      }
    }
  }
}

class RootMenuDrawer extends StatelessWidget {
  const RootMenuDrawer({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 300,
      color: AppColors.charcoalGrey,
      child: Drawer(
        // backgroundColor: AppColors.charcoalGrey,
        elevation: 24,
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 32),
          child: Builder(builder: (myContext) {
            return Column(
              children: [
                SvgPicture.asset(Svgs.logo, width: 180),
                Gap(23),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    SvgPicture.asset(SvgIcons.trendingUp),
                    kGap8,
                    const Text(
                      'MTS = 0,25865\$',
                      style: TextStyle(
                        color: Color(0xff5e5873),
                        fontSize: 14,
                      ),
                    ),
                  ],
                ),
                Expanded(
                  child: ListView(
                    padding: kPad16,
                    shrinkWrap: true,
                    children: [
                      ...kRootMenuList.map2(
                        (e) => _MenuItem(
                          svgId: e.svgId,
                          label: e.label,
                          onTap: () async {
                            var url = e.url;
                            var current = routerLastState!.subloc;

                            /// only push if its NOT the same and is NOT empty
                            if (url.isNotEmpty) {
                              var path = router.namedLocation(url);
                              if (path != current) {
                                context.goNamed(e.url);
                                await 0.25.delay();

                                /// HACK: ONLY WAY TO CLOSE DRAWER.
                                if (kRootMenuKey.currentState?.isDrawerOpen ==
                                    true) {
                                  kRootMenuKey.currentState?.openEndDrawer();
                                }
                              }
                            }
                          },
                        ),
                      ),
                    ],
                  ),
                ),
                kGap16,
                _MenuItem(
                  svgId: SvgIcons.exitToApp,
                  label: 'Log Out',
                  onTap: () {
                    appData.logout();
                  },
                ),
              ],
            );
          }),
        ),
      ),
    );
  }
}

class _MenuItem extends StatelessWidget {
  final VoidCallback? onTap;
  final String label;
  final String svgId;

  const _MenuItem({
    Key? key,
    required this.label,
    required this.svgId,
    this.onTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialButton(
      height: 44,
      onPressed: onTap,
      child: Row(
        children: [
          SvgPicture.asset(
            svgId,
            color: AppColors.appbarIconGrey,
            width: 24,
            height: 24,
            fit: BoxFit.contain,
          ),
          kGap16,
          Text(
            label,
            style: TextStyle(
              color: Color(0xff5e5873),
              fontSize: 14,
              fontFamily: "Open Sans",
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }
}

final kRootMenuList = [
  const _ItemVo(
    label: 'Dashboard',
    svgId: SvgIcons.dashboard,
    url: HomePage.url,
  ),
  const _ItemVo(
    label: 'Finance',
    svgId: SvgIcons.finance,
    url: FinancePage.url,
  ),
  const _ItemVo(
    label: 'My team',
    svgId: SvgIcons.people,
    url: '',
  ),
  const _ItemVo(
    label: 'Store',
    svgId: SvgIcons.store,
    url: '',
  ),
  const _ItemVo(
    label: 'Quest',
    svgId: SvgIcons.quest,
    url: '',
  ),
  const _ItemVo(
    label: 'Roulette',
    svgId: SvgIcons.cardGiftcard,
    url: '',
  ),
  const _ItemVo(
    label: 'Plans',
    svgId: SvgIcons.shoppingBag,
    url: '',
  ),
  const _ItemVo(
    label: 'Portfolio',
    svgId: SvgIcons.inventory,
    url: '',
  ),
  const _ItemVo(
    label: 'Vouchers',
    svgId: SvgIcons.vouchers,
    url: ComingSoonPage.url,
  ),
  const _ItemVo(
    label: 'Binary',
    svgId: SvgIcons.binary,
    url: BinaryPage.url,
  ),
  const _ItemVo(
    label: 'Career',
    svgId: SvgIcons.star,
    url: ComingSoonPage.url,
  ),
  const _ItemVo(
    label: 'Settings',
    svgId: SvgIcons.settings,
    url: SettingsPage.url,
  ),
];

/// root menu data.
class _ItemVo {
  final String svgId;
  final String label;
  final String url;

  const _ItemVo({
    required this.svgId,
    required this.label,
    required this.url,
  });
}

// trending_up.svg
