part of 'wallet_details_modal.dart';

abstract class _WalletDetailsSheetState extends State<WalletDetailsSheet> {
  
  String get titleText => 'Wallet Details Modal page';

  @override
  void initState(){
    super.initState();  
  }

  @override
  void dispose(){
    super.dispose();  
  }
}

