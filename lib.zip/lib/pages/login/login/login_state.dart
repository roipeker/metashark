part of 'login.dart';

abstract class _LoginState extends State<LoginPage> {
  
  String get titleText => 'Login page';

  @override
  void initState(){
    super.initState();  
  }

  @override
  void dispose(){
    super.dispose();  
  }
}

