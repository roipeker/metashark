import 'package:faker/faker.dart';
import 'package:metashark/commons.dart';

final kFaker = Faker();

int _imageCacheCount = 0;

String randomImage([
  int? w = 100,
  int? h,
]) {
  h ??= w;
  return 'https://picsum.photos/$w/$h?random=${_imageCacheCount++}';
}

String randomWalletAddress(){
  // '1NeJEFzY8PbVS9RvYPfDP93iqXxHjav791'
  final kPatt = '#'*34;
  return kFaker.guid.random.fromPatternToHex([kPatt]);
  // return kFaker.guid.guid();
}