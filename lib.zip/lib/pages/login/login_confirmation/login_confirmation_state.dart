part of 'login_confirmation.dart';

abstract class _LoginConfirmationState extends State<LoginConfirmationPage> {
  
  String get titleText => 'Login Confirmation page';

  @override
  void initState(){
    super.initState();  
  }

  @override
  void dispose(){
    super.dispose();  
  }
}

