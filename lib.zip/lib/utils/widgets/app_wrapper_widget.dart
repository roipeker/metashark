import 'package:flutter/cupertino.dart';
import 'package:metashark/commons.dart';

class MyPaint extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint();
    p.color = Colors.deepOrangeAccent;
    canvas.drawRect(Rect.fromLTWH(0, -20, 30, 40), p);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) {
    return true;
  }
}

/// Core widget that wraps all Navigation screens.
/// Used to put Widgets common to all app pages.
/// Like focus management and AppToast.
class AppWrapperWidget extends StatelessWidget {
  final Widget child;

  static Widget builder(BuildContext context, Widget? child) {
    NativeUtils.removeSplash();
    late Widget _child;
    if (child == null) {
      _child = const Center(
        child: Text('No page available.'),
      );
    } else {
      _child = AppWrapperWidget(child: child);
    }
    // return SafeAreaWebFixer(child: _child);
    // CupertinoTheme(
    //     data: CupertinoThemeData(
    //         brightness: Brightness.light,
    //         textTheme: CupertinoTextThemeData(
    //           textStyle: TextStyle(fontFamily: AppFonts.openSans),
    //         )
    //     ),
    return CupertinoTheme(
      data: lightThemeCupertino,
      child: _child,
    );
  }

  const AppWrapperWidget({
    Key? key,
    required this.child,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return AppFocusWidget(
      child: AppToast(
        key: AppToast.toastKey,
        child: child,
      ),
    );
  }
}

/// Wrapper to `unfocus()` text fields and other widget elements
/// when we tap anywhere on the screen EXCEPT the focusable actual widget.
/// Used to dismiss the keyboard.
class AppFocusWidget extends StatelessWidget {
  final Widget? child;

  const AppFocusWidget({Key? key, this.child}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        /// no inner TextField `context` available when using global focus.
        // [FocusScope.of(context).unfocus();] is a no go.
        FocusManager.instance.primaryFocus?.unfocus();
      },
      child: child,
    );
  }
}

class SafeAreaWebFixer extends StatelessWidget {
  final Widget child;

  const SafeAreaWebFixer({Key? key, required this.child}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    if (!kIsWeb) return child;

    /// fix mobile web insets. (notches)
    final query = MediaQuery.of(context);
    final area = WebUtils.getSafeArea();
    return MediaQuery(
      data: query.copyWith(
        viewPadding: area,
        padding: area,
      ),
      child: child,
    );
  }
}
