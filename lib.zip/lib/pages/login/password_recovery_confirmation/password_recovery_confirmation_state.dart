part of 'password_recovery_confirmation.dart';

abstract class _PasswordRecoveryConfirmationState extends State<PasswordRecoveryConfirmationPage> {
  
  String get titleText => 'Password Recovery Confirmation page';

  @override
  void initState(){
    super.initState();  
  }

  @override
  void dispose(){
    super.dispose();  
  }
}

