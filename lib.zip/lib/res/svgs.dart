part of 'resources.dart';

class Svgs {
  Svgs._();

  static const String cat = 'assets/svgs/cat.svg';
  static const String logo = 'assets/svgs/logo.svg';
  static const String walletBubbleChart = 'assets/svgs/wallet_bubble_chart.svg';
}
