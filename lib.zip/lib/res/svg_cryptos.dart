part of 'resources.dart';

class SvgCryptos {
  SvgCryptos._();

  static const String btc = 'assets/svgs/cryptos/BTC.svg';
  static const String dash = 'assets/svgs/cryptos/DASH.svg';
  static const String eth = 'assets/svgs/cryptos/ETH.svg';
  static const String mts = 'assets/svgs/cryptos/MTS.svg';
  static const String trx = 'assets/svgs/cryptos/TRX.svg';
}
