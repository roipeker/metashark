part of 'link_profile_confirmation.dart';

abstract class _LinkProfileConfirmationState extends State<LinkProfileConfirmationPage> {
  
  String get titleText => 'Link Profile Confirmation page';

  @override
  void initState(){
    super.initState();  
  }

  @override
  void dispose(){
    super.dispose();  
  }
}

