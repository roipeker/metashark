part of 'registration_confirmation.dart';

abstract class _RegistrationConfirmationState extends State<RegistrationConfirmationPage> {
  
  String get titleText => 'Registration Confirmation page';

  @override
  void initState(){
    super.initState();  
  }

  @override
  void dispose(){
    super.dispose();  
  }
}

