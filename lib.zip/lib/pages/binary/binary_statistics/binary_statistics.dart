import 'package:metashark/commons.dart';

part 'binary_statistics_state.dart';

class BinaryStatisticsPage extends StatefulWidget {
  // static const url = "/binary-statistics";
  static const urlParamId = "statistics";

  const BinaryStatisticsPage({Key? key}) : super(key: key);

  @override
  createState() => _BinaryStatisticsPage();
}

class _BinaryStatisticsPage extends _BinaryStatisticsState {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(titleText),
      ),
      body: const Center(
        child: Text('Content for Binary Statistics page'),
      ),
    );
  }
}
