part of 'withdraw_confirmation.dart';

abstract class _WithdrawConfirmationState extends State<WithdrawConfirmationPage> {
  
  String get titleText => 'Withdraw Confirmation page';

  @override
  void initState(){
    super.initState();  
  }

  @override
  void dispose(){
    super.dispose();  
  }
}

