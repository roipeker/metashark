part of 'change_email.dart';

abstract class _ChangeEmailState extends State<ChangeEmailPage> {
  
  @override
  void initState(){
    super.initState();  
  }

  @override
  void dispose(){
    super.dispose();  
  }
}

