part of 'registration.dart';

abstract class _RegistrationState extends State<RegistrationPage> {
  
  String get titleText => 'Registration page';

  @override
  void initState(){
    super.initState();  
  }

  @override
  void dispose(){
    super.dispose();  
  }
}

