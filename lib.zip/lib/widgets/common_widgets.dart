import 'package:metashark/commons.dart';

class AppCard extends StatelessWidget {
  final Widget child;
  final BorderRadius? borderRadius;
  final double elevation;
  final EdgeInsets padding;
  final Color? color;
  final Clip? clip;

  const AppCard({
    Key? key,
    required this.child,
    this.color,
    this.clip,
    this.borderRadius,
    this.elevation = 0,
    this.padding = kPad16,
  }) : super(key: key);

  // AppCard(
  // borderRadius: kBorderRadius12,
  // child: Container(),
  // padding: kPad16.copyWith(bottom: 24),
  // elevation: 0,
  // color: AppColors.primaryPurple.withOpacity(.1),
  // );

  const AppCard.settings({
    Key? key,
    required this.child,
    this.padding = kPad16,
  })  : elevation = 0,
        clip = null,
        color = null,
        borderRadius = null,
        super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: elevation,
      shape: borderRadius != null
          ? RoundedRectangleBorder(borderRadius: borderRadius!)
          : kBorder8,
      color: color,
      clipBehavior: clip,
      child: Padding(
        padding: padding,
        child: child,
      ),
    );
  }
}

// --

/// App Wrapper to deal with Navigator and root Menu Drawer.
class CommonAppBar extends StatelessWidget implements PreferredSizeWidget {
  final String? title;
  final List<Widget>? actions;
  final PreferredSizeWidget? bottom;

  const CommonAppBar({
    Key? key,
    this.title,
    this.actions,
    this.bottom,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final menu = RootMenu.of(context);
    final hasDrawer = menu != null;
    late Widget? leading;
    var can = context.canPop();
    if (can) {
      /// show back button.
      leading = BackButton(
        onPressed: () {
          context.pop();
        },
      );
    } else if (hasDrawer) {
      leading = IconButton(
        icon: const Icon(Icons.menu),
        onPressed: () {
          menu.open();
        },
      );
    }

    Widget? _title;
    if (title != null) {
      _title = Text(title!);
    }
    if (actions != null) {
      if (actions!.last != kGap8) {
        actions!.add(kGap8);
      }
    }
    return AppBar(
      title: _title,
      leading: leading,
      actions: actions,
      bottom: bottom,
    );
  }

  @override
  Size get preferredSize => Size(double.infinity, _realHeight);

  double get _realHeight {
    var bottomH = bottom?.preferredSize.height ?? 0;
    return kToolbarHeight + bottomH;
  }
}

// preferredSize = _PreferredAppBarSize(toolbarHeight, bottom?.preferredSize.height),




/// ---- svg

class SvgAvatarIcon extends StatelessWidget {
  final String iconId;
  final double iconSize;
  final double size;
  final Color? backgroundColor;
  final Color? foregroundColor;

  const SvgAvatarIcon({
    Key? key,
    required this.iconId,
    this.iconSize = 18,
    this.size = 32,
    this.backgroundColor,
    this.foregroundColor,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: backgroundColor ?? context.theme.primaryColor,
        shape: BoxShape.circle,
      ),
      width: size,
      height: size,
      alignment: Alignment.center,
      child: SvgPicture.asset(
        iconId,
        width: iconSize,
        height: iconSize,
        fit: BoxFit.contain,
        color: foregroundColor ?? Colors.white,
      ),
    );
  }
}
