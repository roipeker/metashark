part 'images.dart';

part 'images_locale.dart';

part 'svg_cryptos.dart';

part 'svg_icons.dart';

part 'svgs.dart';
