part of 'sessions.dart';

abstract class _SessionsState extends State<SessionsPage> {

  @override
  void initState(){
    super.initState();  
  }

  @override
  void dispose(){
    super.dispose();  
  }
}
