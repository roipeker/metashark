part of 'binary_statistics.dart';

abstract class _BinaryStatisticsState extends State<BinaryStatisticsPage> {
  
  String get titleText => 'Binary Statistics page';

  @override
  void initState(){
    super.initState();  
  }

  @override
  void dispose(){
    super.dispose();  
  }
}

