import 'package:metashark/commons.dart';

/// add data models here.
class MockDataFactory {
  // static CountryVo randomCountryVo() {
  //   final name = kFaker.address.country();
  //   final province = kFaker.address.city();
  //   return CountryVo(
  //     name: name,
  //     province: province,
  //     checked: false,
  //     image: randomImage(70),
  //   );
  // }
  //
  // static LeaderboardUserVo randomLeaderboardUser() {
  //   final firstName = kFaker.person.firstName();
  //   final lastName = kFaker.person.lastName();
  //   return LeaderboardUserVo(
  //     firstName: firstName,
  //     lastName: lastName,
  //     imageUrl: randomImage(40),
  //     points: kFaker.randomGenerator.integer(300, min: 1),
  //   );
  // }

  static final cryptoCurrencies = [
    CurrencyVo(SvgCryptos.btc, 'Bitcoin'),
    CurrencyVo(SvgCryptos.eth, 'Ethereum'),
    CurrencyVo(SvgCryptos.mts, 'MetaShark'),
    CurrencyVo(SvgCryptos.dash, 'Dash'),
    CurrencyVo(SvgCryptos.trx, 'Tron'),
  ];
}

class CurrencyVo {
  final String iconId;
  final String name;
  final String address;

  CurrencyVo(this.iconId, this.name) : address = randomWalletAddress();
}
