part of 'password_recovery.dart';

abstract class _PasswordRecoveryState extends State<PasswordRecoveryPage> {
  
  String get titleText => 'Password Recovery page';

  @override
  void initState(){
    super.initState();  
  }

  @override
  void dispose(){
    super.dispose();  
  }
}

