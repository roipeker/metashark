import 'package:metashark/commons.dart';

part 'binary_state.dart';

part 'model.dart';

class BinaryPage extends StatefulWidget {
  static const url = "/binary";

  static int getUrlIdAsTabIndex(String id) {
    id = id.trim().toLowerCase();
    return kBottomMenuNav.indexWhere((o) => o.urlId == id, 0);
  }

  static bool isValidUrlParam(String id) {
    id = id.trim().toLowerCase();
    for (var o in kBottomMenuNav) {
      if (o.urlId == id) return true;
    }
    return false;
  }

  final int currentTab;

  const BinaryPage({Key? key, this.currentTab = 0}) : super(key: key);

  @override
  createState() => _BinaryPage();
}

class _BinaryPage extends _BinaryState {
  @override
  Widget build(BuildContext context) {
    super.build(context);
    return Scaffold(
      appBar: const CommonAppBar(
        title: 'Binary',
      ),
      body: Center(
        child: Text('Content for Binary page ${currentIndex}'),
      ),
      bottomNavigationBar: BottomNavigationBar(
        items: kBottomMenuNav.map2((e) {
          var iconColor = e == selectedModel
              ? AppColors.primaryPurple
              : AppColors.appbarIconGrey;
          return BottomNavigationBarItem(
            icon: SvgPicture.asset(
              e.iconId,
              color: iconColor,
            ),
            label: e.name,
          );
        }),
        selectedItemColor: AppColors.primaryPurple,
        unselectedItemColor: AppColors.appbarIconGrey,
        selectedLabelStyle:
            TextStyle(fontSize: 14, fontWeight: FontWeight.w500),
        unselectedLabelStyle:
            TextStyle(fontSize: 14, fontWeight: FontWeight.w500),
        type: BottomNavigationBarType.fixed,
        // fixedColor: Colors.red,
        // selectedFontSize: 14,
        currentIndex: currentIndex,
        onTap: onBottomNavTap,
      ),
    );
  }

  BottomNavItemVo get selectedModel => kBottomMenuNav[currentIndex];

  int get currentIndex => widget.currentTab;

  void onBottomNavTap(int index) {
    var url = '/binary/' + kBottomMenuNav[index].urlId;
    context.go(url);
  }
}
