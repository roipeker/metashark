import '../commons.dart';

class AppColors {

  /// green
  static const green = Color(0xff28c76f);
  static const red = Color(0xffea5455);

  static const greyAccesoryIconColor = Color(0xffB9B9C3);

  static const primaryPurple = Color(0xff7367F0);
  static const scaffold = Color(0xffF8F8F8);

  static const denim = Color(0xff384f7d);
  static const denim80 = Color(0xcc384f7d);
  static const duskyBlue = Color(0xff445984);
  static const lightGrassGreen = Color(0xff8ef15c);
  static const duskyBlue30 = Color(0x4d445984);
  static const darkGrey10 = Color(0x1a1e1d20);
  static const charcoalGrey = Color(0xff373a4d);
  static const denim65 = Color(0xa6384f7d);
  static const shamrockGreen = Color(0xff00d23a);
  static const test50 = Color(0x805e5873);

  static const cardShadow = Color(0x805e5873);

  static const appbarIconGrey = Color(0xff5e5873);
  static const darkGreyTitle = Color(0xff5e5873);
}
