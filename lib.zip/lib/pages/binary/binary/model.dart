part of 'binary.dart';

const kBottomMenuNav = <BottomNavItemVo>[
  BottomNavItemVo(
    name: 'Statistics',
    urlId: 'statistics',
    iconId: SvgIcons.pieChart,
  ),
  BottomNavItemVo(
    name: 'Structure',
    urlId: 'structure',
    iconId: SvgIcons.iconMetroFlowTree,
  ),
];

class BottomNavItemVo {
  final String name;
  final String urlId;
  final String iconId;

  const BottomNavItemVo({
    required this.name,
    required this.urlId,
    required this.iconId,
  });
}
