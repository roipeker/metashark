import 'package:intl/intl.dart';

class FormUtils {
  static final dateFormat = DateFormat('dd.MM.y');
// var dateString = format.format(DateTime.now());
}
