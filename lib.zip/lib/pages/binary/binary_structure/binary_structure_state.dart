part of 'binary_structure.dart';

abstract class _BinaryStructureState extends State<BinaryStructurePage> {
  
  String get titleText => 'Binary Structure page';

  @override
  void initState(){
    super.initState();  
  }

  @override
  void dispose(){
    super.dispose();  
  }
}

