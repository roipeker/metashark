part of 'google_auth.dart';

abstract class _GoogleAuthState extends State<GoogleAuthPage> {
  
  String get titleText => 'Google Auth page';

  @override
  void initState(){
    super.initState();  
  }

  @override
  void dispose(){
    super.dispose();  
  }
}

