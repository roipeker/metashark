import 'package:flutter/cupertino.dart';

import 'commons.dart';

Future<void> main() async {
  await AppService.init();
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp.router(
      color: Colors.white,
      routeInformationParser: router.routeInformationParser,
      routerDelegate: router.routerDelegate,
      // scrollBehavior: AppScrollBehavior(),
      debugShowCheckedModeBanner: false,
      useInheritedMediaQuery: true,
      title: AppStrings.appName,
      locale: const Locale('en', 'US'),
      builder: AppWrapperWidget.builder,
      theme: lightTheme,
    );
  }
}
