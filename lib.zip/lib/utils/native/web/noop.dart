import 'package:flutter/material.dart';

void trace2(String msg) {}

abstract class WebUtils {
  static void init() {}

  static void computeSafeArea() {}

  static EdgeInsets getSafeArea() => EdgeInsets.zero;
}
