part of 'home.dart';

abstract class _HomeState extends State<HomePage> {
  
  String get titleText => 'Home page';

  @override
  void initState(){
    super.initState();  
  }

  @override
  void dispose(){
    super.dispose();  
  }
}

