import 'package:metashark/commons.dart';

class ComingSoonPage extends StatelessWidget {
  static const url = 'comingSoon';
  final String title;

  const ComingSoonPage({Key? key, required this.title}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CommonAppBar(
        title: title,
      ),
      body: Center(
        child: Text(
          'Coming soon...',
          style: context.theme.textTheme.headline4,
        ),
      ),
    );
  }
}
